"""Enterprise ready Python OData client"""

from .client import Client

__all__ = ["Client"]
